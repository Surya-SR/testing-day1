const Header = () => {
  return (
        <header className="d-flex align-items-center justify-content-between w-100">
           <a href="/"><img src="/assets/images/react.png" alt="" /></a>
           <div className="">
            Header
           </div>
           <div className="">
            

           </div>
        </header>
  )
}

export default Header