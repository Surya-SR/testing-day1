// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';

// const originalConsoleError = console.error;
// const jsDomCssError = "Error: Could not parse CSS stylesheet";
// console.error = (...params) => {
//   if (!params.find((p) => p.toString().includes(jsDomCssError))) {
//     originalConsoleError(...params);
//   }
// };
